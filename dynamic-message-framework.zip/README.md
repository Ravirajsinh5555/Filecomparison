# Dynamic Message Framework (sample)

This Maven project demonstrates a Java framework that:
- Detects message type (XML or Fixed-Length)
- Generates an InputMapping sheet (fields)
- Generates TestCases sheet (positive + negative per field)
- Writes a single Excel file with two sheets

Build:
```
mvn clean package
```

Run:
```
java -cp target/dynamic-message-framework-1.0.0.jar com.example.dynamic.MessageTestFramework src/test/resources/sample.xml /tmp/out.xlsx
```
