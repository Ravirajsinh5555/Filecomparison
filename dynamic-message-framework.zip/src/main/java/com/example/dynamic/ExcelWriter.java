package com.example.dynamic;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.List;

public class ExcelWriter {

    public static void writeInputMappingSheet(Workbook wb, List<InputMappingRow> rows, MessageType type) {
        Sheet s = wb.createSheet("InputMapping");
        Row h = s.createRow(0);
        if (type == MessageType.XML) {
            String[] headers = {"FieldName","FieldHierarchy","Node/Attribute","Data_Type","Mandatory","Min_Length","Max_Length"};
            for (int i=0;i<headers.length;i++) h.createCell(i).setCellValue(headers[i]);
            int r=1;
            for (InputMappingRow m : rows) {
                Row row = s.createRow(r++);
                int c=0;
                row.createCell(c++).setCellValue(m.getFieldName());
                row.createCell(c++).setCellValue(m.getFieldHierarchy()==null?"":m.getFieldHierarchy());
                row.createCell(c++).setCellValue(m.getNodeType()==null?"":m.getNodeType());
                row.createCell(c++).setCellValue(m.getDataType()==null?"":m.getDataType());
                row.createCell(c++).setCellValue(m.getMandatory()==null?"":m.getMandatory());
                row.createCell(c++).setCellValue(m.getMinLength()==null?"":m.getMinLength());
                row.createCell(c++).setCellValue(m.getMaxLength()==null?"":m.getMaxLength());
            }
        } else {
            String[] headers = {"FieldName","StartPosition","EndPosition","Length","Data_Type","Mandatory"};
            for (int i=0;i<headers.length;i++) h.createCell(i).setCellValue(headers[i]);
            int r=1;
            for (InputMappingRow m : rows) {
                Row row = s.createRow(r++);
                int c=0;
                row.createCell(c++).setCellValue(m.getFieldName());
                row.createCell(c++).setCellValue(m.getStartPosition()==null?0:m.getStartPosition());
                row.createCell(c++).setCellValue(m.getEndPosition()==null?0:m.getEndPosition());
                row.createCell(c++).setCellValue(m.getLength()==null?0:m.getLength());
                row.createCell(c++).setCellValue(m.getDataType()==null?"":m.getDataType());
                row.createCell(c++).setCellValue(m.getMandatory()==null?"":m.getMandatory());
            }
        }
    }

    public static void writeTestCaseSheet(Workbook wb, List<TestCaseRow> cases, List<InputMappingRow> mappingRows) {
        Sheet s = wb.createSheet("TestCases");
        Row h = s.createRow(0);
        String[] staticH = {"SerialNo","Scenario","TestID","TestCaseName","BaselineReqResp","Test_Type","Test_Category","Expected_Result","Description"};
        int c = 0;
        for (String sh : staticH) h.createCell(c++).setCellValue(sh);
        for (InputMappingRow m : mappingRows) {
            h.createCell(c++).setCellValue("Input:" + m.getFieldName());
        }
        int r = 1;
        for (TestCaseRow t : cases) {
            Row row = s.createRow(r++);
            t.writeToRow(row, mappingRows);
        }
    }
}
