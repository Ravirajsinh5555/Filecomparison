package com.example.dynamic;

import java.nio.file.Files;
import java.nio.file.Paths;

public class FilesHelper {
    public static String readFirstLine(String filePath) throws Exception {
        return Files.readAllLines(Paths.get(filePath)).get(0);
    }
}
