package com.example.dynamic;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FixedLengthUtils {
    public static String readFirstLine(String filePath) throws Exception {
        return Files.readAllLines(Paths.get(filePath)).get(0);
    }

    public static List<InputMappingRow> extractFields(String line) {
        List<InputMappingRow> rows = new ArrayList<>();
        // simple whitespace-delimited tokenization with positions
        int pos = 1;
        String[] tokens = line.split("\\s+");
        for (String t : tokens) {
            int len = t.length();
            InputMappingRow r = new InputMappingRow();
            r.setFieldName("Field" + pos);
            r.setStartPosition(pos);
            r.setEndPosition(pos + len - 1);
            r.setLength(len);
            r.setDataType("String");
            r.setMandatory("Y");
            rows.add(r);
            pos += len + 1; // skip delimiter
        }
        return rows;
    }
}
