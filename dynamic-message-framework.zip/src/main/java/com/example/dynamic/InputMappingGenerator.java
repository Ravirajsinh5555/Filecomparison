package com.example.dynamic;

import java.util.List;

public class InputMappingGenerator {

    public static java.util.List<InputMappingRow> generate(String filePath, MessageType type) throws Exception {
        if (type == MessageType.XML) {
            return generateFromXML(filePath);
        } else {
            return generateFromFixed(filePath);
        }
    }

    private static java.util.List<InputMappingRow> generateFromXML(String filePath) throws Exception {
        org.w3c.dom.Document doc = XMLUtils.parse(filePath);
        java.util.List<String> paths = XMLUtils.extractAllXPaths(doc);
        java.util.List<InputMappingRow> rows = new java.util.ArrayList<>();
        for (String p : paths) {
            InputMappingRow r = new InputMappingRow();
            r.setFieldName(XMLUtils.deriveFieldName(p));
            r.setFieldHierarchy(p);
            r.setNodeType("Node");
            r.setDataType("String");
            r.setMandatory("Y");
            r.setMinLength("1");
            r.setMaxLength("50");
            rows.add(r);
        }
        return rows;
    }

    private static java.util.List<InputMappingRow> generateFromFixed(String filePath) throws Exception {
        return FixedLengthUtils.extractFields(FilesHelper.readFirstLine(filePath));
    }
}
