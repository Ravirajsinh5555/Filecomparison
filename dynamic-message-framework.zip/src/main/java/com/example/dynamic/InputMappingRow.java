package com.example.dynamic;

public class InputMappingRow {
    // common
    private String fieldName;
    // XML
    private String fieldHierarchy;
    private String nodeType;
    private String dataType;
    private String mandatory;
    private String minLength;
    private String maxLength;
    // Fixed-length
    private Integer startPosition;
    private Integer endPosition;
    private Integer length;

    // getters and setters
    public String getFieldName() { return fieldName; }
    public void setFieldName(String fieldName) { this.fieldName = fieldName; }
    public String getFieldHierarchy() { return fieldHierarchy; }
    public void setFieldHierarchy(String fieldHierarchy) { this.fieldHierarchy = fieldHierarchy; }
    public String getNodeType() { return nodeType; }
    public void setNodeType(String nodeType) { this.nodeType = nodeType; }
    public String getDataType() { return dataType; }
    public void setDataType(String dataType) { this.dataType = dataType; }
    public String getMandatory() { return mandatory; }
    public void setMandatory(String mandatory) { this.mandatory = mandatory; }
    public String getMinLength() { return minLength; }
    public void setMinLength(String minLength) { this.minLength = minLength; }
    public String getMaxLength() { return maxLength; }
    public void setMaxLength(String maxLength) { this.maxLength = maxLength; }
    public Integer getStartPosition() { return startPosition; }
    public void setStartPosition(Integer startPosition) { this.startPosition = startPosition; }
    public Integer getEndPosition() { return endPosition; }
    public void setEndPosition(Integer endPosition) { this.endPosition = endPosition; }
    public Integer getLength() { return length; }
    public void setLength(Integer length) { this.length = length; }
}
