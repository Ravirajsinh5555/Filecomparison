package com.example.dynamic;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.util.List;

public class MessageTestFramework {
    public static void generateExcelFromMessage(String inputFilePath, String outputExcelPath) throws Exception {
        MessageType type = MessageTypeDetector.detectTypeFromFile(inputFilePath);
        System.out.println("Detected type: " + type);
        List<InputMappingRow> mappingRows = InputMappingGenerator.generate(inputFilePath, type);
        List<TestCaseRow> cases = TestCaseGenerator.generateFromMapping(mappingRows, type);
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            ExcelWriter.writeInputMappingSheet(wb, mappingRows, type);
            ExcelWriter.writeTestCaseSheet(wb, cases, mappingRows);
            try (FileOutputStream fos = new FileOutputStream(outputExcelPath)) {
                wb.write(fos);
            }
        }
        System.out.println("Excel created at: " + outputExcelPath);
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.out.println("Usage: java -jar dynamic-message-framework.jar <inputFile> <outputXlsx>");
            return;
        }
        generateExcelFromMessage(args[0], args[1]);
    }
}
