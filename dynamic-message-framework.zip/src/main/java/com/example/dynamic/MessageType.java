package com.example.dynamic;

public enum MessageType {
    XML, FIXED_LENGTH, UNKNOWN
}
