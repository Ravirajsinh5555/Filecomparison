package com.example.dynamic;

import java.nio.file.Files;
import java.nio.file.Paths;

public class MessageTypeDetector {
    public static MessageType detectTypeFromFile(String filePath) throws Exception {
        String content = new String(Files.readAllBytes(Paths.get(filePath)));
        if (content == null) return MessageType.UNKNOWN;
        String trimmed = content.trim();
        if (trimmed.startsWith("<")) return MessageType.XML;
        // simple heuristic: if contains whitespace-separated tokens and no XML tags -> fixed
        return MessageType.FIXED_LENGTH;
    }
}
