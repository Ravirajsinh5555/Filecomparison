package com.example.dynamic;

import java.util.*;

public class NegativeTestGenerator {

    public static List<TestCaseRow> generateForField(int startSerial, InputMappingRow field) {
        List<TestCaseRow> list = new ArrayList<>();
        int s = startSerial;
        // Blank
        list.add(make(s++, field, "BLANK_VALUE", "", "" ));
        // Invalid
        list.add(make(s++, field, "INVALID_DATA", "INVALID", "@@@" ));
        // Special chars
        list.add(make(s++, field, "SPECIAL_CHARS", "SPECIAL", "<script>alert(1)</script>" ));
        // Boundary low
        list.add(make(s++, field, "BOUNDARY_LOW", "BOUNDARY", "" ));
        // Boundary high
        list.add(make(s++, field, "BOUNDARY_HIGH", "BOUNDARY", new String(new char[60]).replace('\0', 'A') ));
        return list;
    }

    private static TestCaseRow make(int serial, InputMappingRow f, String category, String catLabel, String value) {
        TestCaseRow t = new TestCaseRow();
        t.setSerialNo(serial);
        t.setScenario("Negative Test (" + category + ") for " + f.getFieldName());
        t.setTestID("NEG_" + serial);
        t.setTestCaseName("Negative_" + f.getFieldName() + "_" + category);
        t.setBaselineReqResp("Negative_Base");
        t.setTestType("NEGATIVE");
        t.setTestCategory(category);
        t.setExpectedResult("FAIL");
        t.setDescription("Negative: " + category + " for " + f.getFieldName());
        Map<String,String> inputs = new HashMap<>();
        inputs.put("Input:" + f.getFieldName(), value);
        t.setInputs(inputs);
        return t;
    }
}
