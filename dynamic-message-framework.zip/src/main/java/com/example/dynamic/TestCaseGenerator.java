package com.example.dynamic;

import java.util.*;

public class TestCaseGenerator {

    public static List<TestCaseRow> generateFromMapping(List<InputMappingRow> mappingRows, MessageType type) {
        List<TestCaseRow> cases = new ArrayList<>();
        int serial = 1;
        // create one baseline positive covering all fields
        TestCaseRow baseline = new TestCaseRow();
        baseline.setSerialNo(serial++);
        baseline.setScenario("Baseline all-valid");
        baseline.setTestID("POS_001");
        baseline.setTestCaseName("AllFields_Valid");
        baseline.setBaselineReqResp("Positive_Base");
        baseline.setTestType("POSITIVE");
        baseline.setTestCategory("VALID_DATA");
        baseline.setExpectedResult("PASS");
        baseline.setDescription("All fields valid baseline");
        Map<String,String> inputs = new HashMap<>();
        for (InputMappingRow m : mappingRows) {
            inputs.put("Input:" + m.getFieldName(), defaultValidValue(m));
        }
        baseline.setInputs(inputs);
        cases.add(baseline);

        // per-field negative cases
        for (InputMappingRow m : mappingRows) {
            int s = serial;
            List<TestCaseRow> negs = NegativeTestGenerator.generateForField(s, m);
            cases.addAll(negs);
            serial += negs.size();
        }
        return cases;
    }

    private static String defaultValidValue(InputMappingRow m) {
        if (m.getDataType()!=null && m.getDataType().toLowerCase().contains("int")) return "1";
        return m.getFieldName() + "_VAL";
    }
}
