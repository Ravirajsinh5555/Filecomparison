package com.example.dynamic;

import org.apache.poi.ss.usermodel.Row;

import java.util.Map;

public class TestCaseRow {
    private int serialNo;
    private String scenario;
    private String testID;
    private String testCaseName;
    private String baselineReqResp;
    private String testType;
    private String testCategory;
    private String expectedResult;
    private String description;
    private Map<String,String> inputs;

    // getters/setters
    public int getSerialNo() { return serialNo; }
    public void setSerialNo(int serialNo) { this.serialNo = serialNo; }
    public String getScenario() { return scenario; }
    public void setScenario(String scenario) { this.scenario = scenario; }
    public String getTestID() { return testID; }
    public void setTestID(String testID) { this.testID = testID; }
    public String getTestCaseName() { return testCaseName; }
    public void setTestCaseName(String testCaseName) { this.testCaseName = testCaseName; }
    public String getBaselineReqResp() { return baselineReqResp; }
    public void setBaselineReqResp(String baselineReqResp) { this.baselineReqResp = baselineReqResp; }
    public String getTestType() { return testType; }
    public void setTestType(String testType) { this.testType = testType; }
    public String getTestCategory() { return testCategory; }
    public void setTestCategory(String testCategory) { this.testCategory = testCategory; }
    public String getExpectedResult() { return expectedResult; }
    public void setExpectedResult(String expectedResult) { this.expectedResult = expectedResult; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Map<String,String> getInputs() { return inputs; }
    public void setInputs(Map<String,String> inputs) { this.inputs = inputs; }

    public void writeToRow(Row row, java.util.List<InputMappingRow> mappingRows) {
        int c = 0;
        row.createCell(c++).setCellValue(serialNo);
        row.createCell(c++).setCellValue(scenario==null?"":scenario);
        row.createCell(c++).setCellValue(testID==null?"":testID);
        row.createCell(c++).setCellValue(testCaseName==null?"":testCaseName);
        row.createCell(c++).setCellValue(baselineReqResp==null?"":baselineReqResp);
        row.createCell(c++).setCellValue(testType==null?"":testType);
        row.createCell(c++).setCellValue(testCategory==null?"":testCategory);
        row.createCell(c++).setCellValue(expectedResult==null?"":expectedResult);
        row.createCell(c++).setCellValue(description==null?"":description);
        // dynamic inputs: order by mappingRows
        for (InputMappingRow m : mappingRows) {
            String key = "Input:" + m.getFieldName();
            String val = (inputs!=null && inputs.containsKey(key)) ? inputs.get(key) : "";
            row.createCell(c++).setCellValue(val);
        }
    }
}
