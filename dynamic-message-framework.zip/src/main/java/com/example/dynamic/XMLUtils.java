package com.example.dynamic;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class XMLUtils {
    public static Document parse(String filePath) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(filePath));
    }

    public static List<String> extractAllXPaths(Document doc) {
        List<String> paths = new ArrayList<>();
        Node root = doc.getDocumentElement();
        traverse(root, "", paths);
        return paths;
    }

    private static void traverse(Node node, String path, List<String> paths) {
        if (node.getNodeType() != Node.ELEMENT_NODE) return;
        String current = path + "/" + node.getNodeName();
        NodeList children = node.getChildNodes();
        boolean hasElement = false;
        for (int i=0;i<children.getLength();i++) {
            if (children.item(i).getNodeType() == Node.ELEMENT_NODE) {
                hasElement = true;
                traverse(children.item(i), current, paths);
            }
        }
        if (!hasElement) {
            paths.add(current);
        }
    }

    public static String deriveFieldName(String xpath) {
        String[] p = xpath.split("/");
        return p[p.length-1];
    }
}
