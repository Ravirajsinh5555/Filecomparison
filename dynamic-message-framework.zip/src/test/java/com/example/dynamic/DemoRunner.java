package com.example.dynamic;

public class DemoRunner {
    public static void main(String[] args) throws Exception {
        String xml = "src/test/resources/sample.xml";
        String out = " /mnt/data/generated_testcases_from_xml.xlsx";
        MessageTestFramework.generateExcelFromMessage(xml, "/mnt/data/generated_testcases_from_xml.xlsx");
        MessageTestFramework.generateExcelFromMessage("src/test/resources/sample.fixed", "/mnt/data/generated_testcases_from_fixed.xlsx");
        System.out.println("Done demos. Files in /mnt/data/");
    }
}
